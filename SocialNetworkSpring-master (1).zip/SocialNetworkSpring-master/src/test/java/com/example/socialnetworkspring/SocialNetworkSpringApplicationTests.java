package com.example.socialnetworkspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocialNetworkSpringApplicationTests {

    @Test
    void contextLoads() {
    }

}
